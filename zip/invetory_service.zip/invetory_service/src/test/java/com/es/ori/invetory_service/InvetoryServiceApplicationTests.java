package com.es.ori.invetory_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvetoryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
